package poesemester2question2;

import java.text.SimpleDateFormat;
import java.util.Date;
import static org.junit.jupiter.params.shadow.com.univocity.parsers.conversions.Conversions.string;

public class Order {
    private String orderID;
    private Date orderDate;
    private double amount;
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public Order(String orderID, Date orderDate, double amount) {
        this.orderID = orderID;
        this.orderDate = orderDate;
        this.amount = amount;
    }

    public String getOrderID() {
        return orderID;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public double getAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return String.format("Order ID: " + orderID + ", Date: " + dateFormat.format(orderDate) + ", Amount: " + amount);
    }
}


