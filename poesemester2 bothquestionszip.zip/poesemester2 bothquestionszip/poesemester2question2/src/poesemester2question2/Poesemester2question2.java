
package poesemester2question2;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Poesemester2question2{
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CRMSystem crm = new CRMSystem();

        while (true) {
            System.out.println("\nCRM System Menu:");
            System.out.println("1. Add Customer");
            System.out.println("2. Add Order");
            System.out.println("3. Add Feedback");
            System.out.println("4. List Customers");
            System.out.println("5. List Orders");
            System.out.println("6. List Feedbacks");
            System.out.println("7. Search Customer by ID");
            System.out.println("8. Search Order by ID");
            System.out.println("9. Search Feedback by Order ID");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    // Add Customer
                    System.out.print("Enter customer name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter customer email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter customer phone number: ");
                    String phoneNumber = scanner.nextLine();
                    System.out.print("Enter customer ID: ");
                    String customerID = scanner.nextLine();
                    crm.addCustomer(new Customer(name, email, phoneNumber, customerID));
                    System.out.println("Customer added successfully.");
                    break;

                case 2:
                    // Add Order
                    System.out.print("Enter order ID: ");
                    String orderID = scanner.nextLine();
                    System.out.print("Enter order date (yyyy-MM-dd): ");
                    String dateStr = scanner.nextLine();
                    Date orderDate;
                    try {
                        orderDate = dateFormat.parse(dateStr);
                    } catch (ParseException e) {
                        System.out.println("Invalid date format. Order not added.");
                        break;
                    }
                    System.out.print("Enter order amount: ");
                    double amount = scanner.nextDouble();
                    scanner.nextLine();  // Consume newline
                    crm.addOrder(new Order(orderID, orderDate, amount));
                    System.out.println("Order added successfully.");
                    break;

                case 3:
                    // Add Feedback
                    System.out.print("Enter customer ID for feedback: ");
                    String feedbackCustomerID = scanner.nextLine();
                    System.out.print("Enter order ID for feedback: ");
                    String feedbackOrderID = scanner.nextLine();
                    System.out.print("Enter feedback comments: ");
                    String comments = scanner.nextLine();
                    crm.addFeedback(new Feedback(feedbackCustomerID, feedbackOrderID, comments));
                    System.out.println("Feedback added successfully.");
                    break;

                case 4:
                    // List Customers
                    System.out.println("\nListing all customers:");
                    crm.listCustomers();
                    break;

                case 5:
                    // List Orders
                    System.out.println("\nListing all orders:");
                    crm.listOrders();
                    break;

                case 6:
                    // List Feedbacks
                    System.out.println("\nListing all feedbacks:");
                    crm.listFeedbacks();
                    break;

                case 7:
                    // Search Customer by ID
                    System.out.print("Enter customer ID to search: ");
                    String searchCustomerID = scanner.nextLine();
                    Customer customer = crm.searchCustomerByID(searchCustomerID);
                    if (customer != null) {
                        System.out.println("Found customer: " + customer);
                    } else {
                        System.out.println("Customer not found.");
                    }
                    break;

                case 8:
                    // Search Order by ID
                    System.out.print("Enter order ID to search: ");
                    String searchOrderID = scanner.nextLine();
                    Order order = crm.searchOrderByID(searchOrderID);
                    if (order != null) {
                        System.out.println("Found order: " + order);
                    } else {
                        System.out.println("Order not found.");
                    }
                    break;

                case 9:
                    // Search Feedback by Order ID
                    System.out.print("Enter order ID to search for feedback: ");
                    String searchFeedbackOrderID = scanner.nextLine();
                    List<Feedback> feedbacks = crm.searchFeedbackByOrderID(searchFeedbackOrderID);
                    if (!feedbacks.isEmpty()) {
                        System.out.println("Feedbacks for order ID " + searchFeedbackOrderID + ":");
                        feedbacks.forEach(f -> System.out.println(f.getComments()));
                    } else {
                        System.out.println("No feedbacks found for the specified order.");
                    }
                    break;

                case 0:
                    // Exit
                    System.out.println("Exiting the CRM system.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please enter a number between 0 and 9.");
                    break;
            }
        }
    }
}
