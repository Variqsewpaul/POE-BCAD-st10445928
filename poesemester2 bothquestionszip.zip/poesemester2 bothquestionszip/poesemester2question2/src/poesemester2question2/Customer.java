package poesemester2question2;

public class Customer extends Person {
    private String customerID;

    public Customer(String name, String email, String phone, String customerID) {
        super(name, email, phone);
        this.customerID = customerID;
    }

    public String getCustomerID() {
        return customerID;
    }

    @Override
    public String toString() {
        return String.format("Customer ID: %s, Name: %s, Email: %s, Phone: %s",
                customerID, getName(), getEmail(), getPhone());
    }
}
