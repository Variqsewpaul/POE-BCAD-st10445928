package poesemester2question2;
import java.util.ArrayList;
import java.util.List;

public class CRMSystem {
    private List<Customer> customers;
    private List<Order> orders;
    private List<Feedback> feedbacks;

    public CRMSystem() {
        customers = new ArrayList<>();
        orders = new ArrayList<>();
        feedbacks = new ArrayList<>();
    }

    // Add a customer
    public void addCustomer(Customer customer) {
        customers.add(customer);
    }

    // Add an order
    public void addOrder(Order order) {
        orders.add(order);
    }

    // Add feedback
    public void addFeedback(Feedback feedback) {
        feedbacks.add(feedback);
    }

    // Get all customers
    public List<Customer> getCustomers() {
        return new ArrayList<>(customers);
    }

    // Get all orders
    public List<Order> getOrders() {
        return new ArrayList<>(orders);
    }

    // Get all feedbacks
    public List<Feedback> getFeedbacks() {
        return new ArrayList<>(feedbacks);
    }

    // List customers
    public void listCustomers() {
        if (customers.isEmpty()) {
            System.out.println("No customers available.");
        } else {
            customers.forEach(System.out::println);
        }
    }

    // List orders
    public void listOrders() {
        if (orders.isEmpty()) {
            System.out.println("No orders available.");
        } else {
            orders.forEach(System.out::println);
        }
    }

    // List feedbacks
    public void listFeedbacks() {
        if (feedbacks.isEmpty()) {
            System.out.println("No feedbacks available.");
        } else {
            feedbacks.forEach(System.out::println);
        }
    }

    // Search for a customer by ID
    public Customer searchCustomerByID(String customerID) {
        for (Customer customer : customers) {
            if (customer.getCustomerID().equals(customerID)) {
                return customer;
            }
        }
        return null;
    }

    // Search for an order by ID
    public Order searchOrderByID(String orderID) {
        for (Order order : orders) {
            if (order.getOrderID().equals(orderID)) {
                return order;
            }
        }
        return null;
    }

    // Search for feedbacks by order ID
    public List<Feedback> searchFeedbackByOrderID(String orderID) {
        List<Feedback> result = new ArrayList<>();
        for (Feedback feedback : feedbacks) {
            if (feedback.getOrderID().equals(orderID)) {
                result.add(feedback);
            }
        }
        return result;
    }
}


