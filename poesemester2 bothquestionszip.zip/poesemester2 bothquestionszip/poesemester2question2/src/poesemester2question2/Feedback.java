package poesemester2question2;

public class Feedback {
    private String customerID;
    private String orderID;
    private String comments;

    public Feedback(String customerID, String orderID, String comments) {
        this.customerID = customerID;
        this.orderID = orderID;
        this.comments = comments;
    }

    public String getCustomerID() {
        return customerID;
    }

    public String getOrderID() {
        return orderID;
    }

    public String getComments() {
        return comments;
    }

    @Override
    public String toString() {
        return String.format("Customer ID: %s, Order ID: %s, Comments: %s", customerID, orderID, comments);
    }
}

