package poesemester2question2;
import org.junit.Before;
import org.junit.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

public class CRMSystemTest {
    private CRMSystem crmSystem;
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    @Before
    public void setUp() {
        crmSystem = new CRMSystem();
    }

    @Test
    public void testAddAndListCustomers() {
        crmSystem.addCustomer(new Customer("John Doe", "john@example.com", "1234567890", "C001"));
        crmSystem.addCustomer(new Customer("Jane Smith", "jane@example.com", "0987654321", "C002"));

        // Check if customers are added correctly
        List<Customer> customers = crmSystem.getCustomers(); // Assume there's a getter for testing
        assertEquals(2, customers.size());
        assertTrue(customers.stream().anyMatch(c -> c.getCustomerID().equals("C001")));
        assertTrue(customers.stream().anyMatch(c -> c.getCustomerID().equals("C002")));
    }

    @Test
    public void testAddAndListOrders() throws ParseException {
        Date date = dateFormat.parse("2024-08-31");
        crmSystem.addOrder(new Order("O001", date, 250.75));
        crmSystem.addOrder(new Order("O002", date, 450.50));

        // Check if orders are added correctly
        List<Order> orders = crmSystem.getOrders(); // Assume there's a getter for testing
        assertEquals(2, orders.size());
        assertTrue(orders.stream().anyMatch(o -> o.getOrderID().equals("O001")));
        assertTrue(orders.stream().anyMatch(o -> o.getOrderID().equals("O002")));
    }

    @Test
    public void testAddAndListFeedbacks() {
        crmSystem.addFeedback(new Feedback("C001", "O001", "Great service."));
        crmSystem.addFeedback(new Feedback("C002", "O002", "Satisfied with the order."));

        // Check if feedbacks are added correctly
        List<Feedback> feedbacks = crmSystem.getFeedbacks(); // Assume there's a getter for testing
        assertEquals(2, feedbacks.size());
        assertTrue(feedbacks.stream().anyMatch(f -> f.getOrderID().equals("O001")));
        assertTrue(feedbacks.stream().anyMatch(f -> f.getOrderID().equals("O002")));
    }

    @Test
    public void testSearchCustomerByID() {
        crmSystem.addCustomer(new Customer("John Doe", "john@example.com", "1234567890", "C001"));
        crmSystem.addCustomer(new Customer("Jane Smith", "jane@example.com", "0987654321", "C002"));

        // Test valid ID
        Customer customer = crmSystem.searchCustomerByID("C001");
        assertNotNull(customer);
        assertEquals("John Doe", customer.getName());

        // Test invalid ID
        Customer missingCustomer = crmSystem.searchCustomerByID("C999");
        assertNull(missingCustomer);
    }

    @Test
    public void testSearchOrderByID() throws ParseException {
        Date date = dateFormat.parse("2024-08-31");
        crmSystem.addOrder(new Order("O001", date, 250.75));
        crmSystem.addOrder(new Order("O002", date, 450.50));

        // Test valid ID
        Order order = crmSystem.searchOrderByID("O001");
        assertNotNull(order);
        assertEquals(250.75, order.getAmount(), 0.01); // Allowable delta for floating point comparison

        // Test invalid ID
        Order missingOrder = crmSystem.searchOrderByID("O999");
        assertNull(missingOrder);
    }

    @Test
    public void testSearchFeedbackByOrderID() {
        crmSystem.addFeedback(new Feedback("C001", "O001", "Great service."));
        crmSystem.addFeedback(new Feedback("C002", "O002", "Satisfied with the order."));

        // Test valid order ID
        List<Feedback> feedbacks = crmSystem.searchFeedbackByOrderID("O001");
        assertEquals(1, feedbacks.size());
        assertEquals("Great service.", feedbacks.get(0).getComments());

        // Test invalid order ID
        List<Feedback> noFeedbacks = crmSystem.searchFeedbackByOrderID("O999");
        assertTrue(noFeedbacks.isEmpty());
    }
}


