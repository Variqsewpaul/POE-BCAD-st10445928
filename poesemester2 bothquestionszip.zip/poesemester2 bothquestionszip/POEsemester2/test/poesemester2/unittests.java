package poesemester2;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.Scanner;
import static org.junit.Assert.*;

public class unittests {

    @Before
    public void setUp() {
        // Clear the student list before each test to ensure a clean state
        // This ensures that tests do not interfere with each other
        Student.clearStudentList();
    }

    @Test
    public void testSaveStudent() {
        // Test data
        String id = "12345";
        String name = "John Doe";
        int age = 20;
        String email = "johndoe@example.com";
        String course = "Computer Science";

        // Save the student using the overloaded saveStudent method
        // Method overloading: Resource - "Java: The Complete Reference" by Herbert Schildt, Chapter 7 (Methods and Classes)
        Student.saveStudent(id, name, age, email, course);

        // Retrieve the student by ID
        Student savedStudent = Student.searchStudent(id);

        // Assert that the student was saved correctly
        // Using assertions to verify expected results: Resource - "Effective Java" by Joshua Bloch, Chapter 7 (Methods)
        assertNotNull("Student should be saved and not null", savedStudent);
        assertEquals("Student ID should match", id, savedStudent.getId());
        assertEquals("Student name should match", name, savedStudent.getName());
        assertEquals("Student age should match", age, savedStudent.getAge());
        assertEquals("Student email should match", email, savedStudent.getEmail());
        assertEquals("Student course should match", course, savedStudent.getCourse());
    }

    @After
    public void tearDown() {
        // Clear the student list after each test to ensure no side effects between tests
        // This ensures the test environment is reset after each test case
        Student.clearStudentList();
    }

    @Test
    public void testSearchStudentNotFound() {
        // Attempt to search for a student that doesn't exist
        // Testing edge cases: Resource - "JUnit in Action" by Petar Tahchiev, Chapter 4 (Practical Unit Testing)
        Student foundStudent = Student.searchStudent("nonexistentID");

        // Assert that no student is found
        assertNull("Student should not be found and should be null", foundStudent);
    }
    
    @After
    public void tear() {
        // Clear the student list after each test to ensure no side effects between tests
        // This ensures the test environment is reset after each test case
        Student.clearStudentList();
        
    }
    @Test
public void TestSaveStudent() {
    // Step 1: Create the test data for a student
    String id = "S1004";
    String name = "Emily Clark";
    int age = 22;
    String email = "emilyclark@example.com";
    String course = "Biology";

    // Step 2: Save the student using the saveStudent method
    Student.saveStudent(id, name, age, email, course);

    // Step 3: Retrieve the student by ID
    Student savedStudent = Student.searchStudent(id);

    // Step 4: Assert that the student was saved correctly
    assertNotNull("Student should be saved and not null", savedStudent);
    assertEquals("Student ID should match", id, savedStudent.getId());
    assertEquals("Student name should match", name, savedStudent.getName());
    assertEquals("Student age should match", age, savedStudent.getAge());
    assertEquals("Student email should match", email, savedStudent.getEmail());
    assertEquals("Student course should match", course, savedStudent.getCourse());
}


    @After
    public void clean() {
        // Clear the student list after each test to ensure no side effects between tests
        Student.clearStudentList();
    }

    @Test
    public void testDeleteStudent() {
        // Step 1: Add a student to the list
        String id = "67890";
        String name = "Alice Johnson";
        int age = 21;
        String email = "alicejohnson@example.com";
        String course = "Business Management";

        // Add student to the list: Resource - "Java: The Complete Reference" by Herbert Schildt, Chapter 8 (Classes and Objects)
        Student.saveStudent(id, name, age, email, course);

        // Verify that the student was added successfully
        assertNotNull("Student should be found before deletion", Student.searchStudent(id));

        // Simulate the deletion process
        // For simplicity, simulate user input directly via refactoring
        boolean isDeleted = deleteStudent(id, "y");

        // Verify that the student was deleted
        assertTrue("Student should be successfully deleted", isDeleted);
        assertNull("Student should not be found after deletion", Student.searchStudent(id));
    }

    // Refactored deleteStudent method for testing purposes
    // This method simulates user input for deletion confirmation
    private boolean deleteStudent(String id, String confirmation) {
        // Find the student in the list
        Student studentToDelete = null;
        for (Student student : Student.getStudents()) {
            if (student.getId().equals(id)) {
                studentToDelete = student;
                break;
            }
        }

        // If student is found, check the confirmation before deletion
        if (studentToDelete != null) {
            // Simulate the confirmation step
            if (confirmation.equalsIgnoreCase("y")) {
                Student.getStudents().remove(studentToDelete);
                System.out.println("Student with ID " + id + " has been successfully deleted.");
                return true;
            } else {
                System.out.println("Student deletion canceled.");
                return false;
            }
        } else {
            System.out.println("Error: Student with ID " + id + " cannot be located.");
            return false;
        }
    }

    @After
    public void clear() {
        // Clear the student list after each test to ensure no side effects between tests
        Student.clearStudentList();
    }

    @Test
    public void testDeleteStudent_StudentNotFound() {
        // Step 1: Attempt to delete a student with an incorrect ID
        String incorrectId = "nonexistentID";

        // Step 2: Call the deleteStudent method with the incorrect ID
        boolean isDeleted = deleteStudent(incorrectId, "y");

        // Step 3: Verify that no student was deleted
        assertFalse("No student should be deleted as the ID is incorrect", isDeleted);

        // Verify that the student list is still empty (or unchanged)
        assertTrue("The student list should remain unchanged", Student.getStudents().isEmpty());
    }

    @After
    public void reset() {
        // Clear the student list after each test to ensure no side effects between tests
        Student.clearStudentList();
    }

    @Test
    public void TestStudentAge_StudentAgeValid() {
        // Create input data
        String id = "S1001";
        String name = "John Doe";
        String validAge = "18";  // Valid age
        String email = "johndoe@example.com";
        String course = "Computer Science";
        String exitChoice = "1";  // Assuming the user wants to launch the menu again after saving

        // Simulate user inputs using a custom Scanner
        String input = id + "\n" + name + "\n" + validAge + "\n" + email + "\n" + course + "\n" + exitChoice + "\n";
        Scanner scanner = new Scanner(input);

        // Call saveStudent method with custom Scanner
        Student.saveStudent(scanner);

        // Validate the student is saved with the correct age
        assertEquals(1, Student.getStudents().size());  // Ensure one student is added
        Student savedStudent = Student.getStudents().get(0);
        assertEquals("The student age should be valid and correctly set", 18, savedStudent.getAge());
        assertEquals("The student ID should be correctly set", id, savedStudent.getId());
        assertEquals("The student name should be correctly set", name, savedStudent.getName());
        assertEquals("The student email should be correctly set", email, savedStudent.getEmail());
        assertEquals("The student course should be correctly set", course, savedStudent.getCourse());
    }

    @After
    public void erase() {
        // Clear the student list after each test to ensure no side effects between tests
        Student.clearStudentList();
    }

    @Test
    public void TestStudentAge_StudentAgeInvalid() {
        // Create input data
        String id = "S1002";
        String name = "Jane Doe";
        String invalidAge = "15";  // Invalid age (less than 16)
        String validAge = "18";    // Valid age to follow after invalid attempt
        String email = "janedoe@example.com";
        String course = "Mathematics";
        String exitChoice = "1";   // Assuming the user wants to launch the menu again after saving

        // Simulate user inputs using a custom Scanner
        String input = id + "\n" + name + "\n" + invalidAge + "\n" + validAge + "\n" + email + "\n" + course + "\n" + exitChoice + "\n";
        Scanner scanner = new Scanner(input);

        // Call saveStudent method with custom Scanner
        Student.saveStudent(scanner);

        // Validate the student is saved with the correct age after initially providing an invalid age
        assertEquals(1, Student.getStudents().size());  // Ensure one student is added
        Student savedStudent = Student.getStudents().get(0);
        assertEquals("The student age should be correctly set to the valid age after invalid input", 18, savedStudent.getAge());
        assertEquals("The student ID should be correctly set", id, savedStudent.getId());
        assertEquals("The student name should be correctly set", name, savedStudent.getName());
        assertEquals("The student email should be correctly set", email, savedStudent.getEmail());
        assertEquals("The student course should be correctly set", course, savedStudent.getCourse());
    }

    @After
    public void remove() {
        // Clear the student list after each test to ensure no side effects between tests
        Student.clearStudentList();
    }

    @Test
    public void TestStudentAge_StudentAgeInvalidCharacter() {
        // Create input data
        String id = "S1003";
        String name = "John Smith";
        String invalidAge = "abc"; // Invalid character input
        String validAge = "20";    // Valid age to follow after invalid attempt
        String email = "johnsmith@example.com";
        String course = "Computer Science";
        String exitChoice = "1";   // Assuming the user wants to launch the menu again after saving

        // Simulate user inputs using a custom Scanner
        String input = id + "\n" + name + "\n" + invalidAge + "\n" + validAge + "\n" + email + "\n" + course + "\n" + exitChoice + "\n";
        Scanner scanner = new Scanner(input);

        // Call saveStudent method with custom Scanner
        Student.saveStudent(scanner);

        // Validate the student is saved with the correct age after initially providing an invalid character
        assertEquals(1, Student.getStudents().size());  // Ensure one student is added
        Student savedStudent = Student.getStudents().get(0);
        assertEquals("The student age should be correctly set to the valid age after invalid input", 20, savedStudent.getAge());
        assertEquals("The student ID should be correctly set", id, savedStudent.getId());
        assertEquals("The student name should be correctly set", name, savedStudent.getName());
        assertEquals("The student email should be correctly set", email, savedStudent.getEmail());
        assertEquals("The student course should be correctly set", course, savedStudent.getCourse());
    }
}






