package poesemester2;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Student {
    // Instance variables for student details
    private String id;         // Stores student ID
    private String name;       // Stores student name
    private int age;           // Stores student age
    private String email;      // Stores student email
    private String course;     // Stores student course

    // List to store all students
    private static List<Student> students = new ArrayList<>();

    // Scanner object for user input
    private static Scanner scanner = new Scanner(System.in);

    // Constructor to initialize student object (used in saveStudent method)
    // Resource: "Java: The Complete Reference" by Herbert Schildt - Chapter 7 (Object-Oriented Programming)
    public Student(String id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    // Getters for student properties (used in searchStudent and studentReport methods)
    // Resource: "Effective Java" by Joshua Bloch - Item 16 (Prefer to provide methods instead of exposing fields)
    public String getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getEmail() { return email; }
    public String getCourse() { return course; }

    /**
     * Method to save a new student.
     * Prompts the user for all necessary student details, validates age, and adds the student to the list.
     * Referenced in: Main.launchManager() -> case "1"
     * Resource: "Head First Java" by Kathy Sierra, Bert Bates - Chapter 10 (Constructors and Object Creation)
     */
    public static void saveStudent(Scanner scanner) {
    // Prompt user for student details
    System.out.print("Enter student ID: ");
    String id = scanner.nextLine();

    System.out.print("Enter student name: ");
    String name = scanner.nextLine();

    // Validate student age input (age >= 16 and must be a number)
    int age = 0;
    boolean validAge = false;
    while (!validAge) {
        System.out.print("Enter student age: ");
        String ageInput = scanner.nextLine();
        try {
            age = Integer.parseInt(ageInput);
            if (age >= 16) {
                validAge = true;
            } else {
                System.out.println("You have entered an incorrect student age !!!");
                System.out.println("Please re-enter the student age >>");
            }
        } catch (NumberFormatException e) {
            System.out.println("You have entered an incorrect student age !!!");
            System.out.println("Please re-enter the student age >>");
        }
    }

    // Capture email and course
    System.out.print("Enter student email: ");
    String email = scanner.nextLine();

    System.out.print("Enter student course: ");
    String course = scanner.nextLine();

    // Create a new Student object and add it to the students list
    Student student = new Student(id, name, age, email, course);
    students.add(student);

    // Confirm to the user that the student was successfully saved
    System.out.println("Student details have been successfully saved!");

    // Option to return to the main menu or exit the application
    System.out.print("Press (1) to launch menu or any other key to exit: ");
    String choice = scanner.nextLine();
    if (!"1".equals(choice)) {
        exitStudentApplication();  // Exit if the user doesn't choose to return to the menu
    }
}


    /**
     * Method to search for a student by ID.
     * If the student is found, their details are displayed. If not, an error message is shown.
     * Referenced in: Main.launchManager() -> case "2"
     * Resource: "Java Programming" by Joyce Farrell - Chapter 9 (Arrays and ArrayLists)
     */
    public static void searchStudent() {
        System.out.print("Enter student ID to search: ");
        String id = scanner.nextLine();

        // Iterate through the list to find the student
        boolean found = false;
        for (Student student : students) {
            if (student.getId().equals(id)) {
                // If student is found, print their details
                System.out.println("Student found:");
                System.out.println("ID: " + student.getId());
                System.out.println("Name: " + student.getName());
                System.out.println("Age: " + student.getAge());
                System.out.println("Email: " + student.getEmail());
                System.out.println("Course: " + student.getCourse());
                found = true;
                break;
            }
        }

        // If no student was found, display an error message
        if (!found) {
            System.out.println("Error: Student with ID " + id + " cannot be located.");
        }

        // Option to return to the main menu or exit the application
        System.out.print("Press (1) to launch menu or any other key to exit: ");
        String choice = scanner.nextLine();
        if (!"1".equals(choice)) {
            exitStudentApplication();  // Exit if the user doesn't choose to return to the menu
        }
    }

    /**
     * Method to delete a student by ID.
     * The user must confirm the deletion. If confirmed, the student is removed from the list.
     * Referenced in: Main.launchManager() -> case "3"
     * Resource: "Head First Java" by Kathy Sierra, Bert Bates - Chapter 11 (Handling Errors and Exceptions)
     */
    public static void deleteStudent() {
        System.out.print("Enter student ID to delete: ");
        String id = scanner.nextLine();

        // Find the student in the list
        Student studentToDelete = null;
        for (Student student : students) {
            if (student.getId().equals(id)) {
                studentToDelete = student;
                break;
            }
        }

        // If student is found, ask for confirmation before deletion
        if (studentToDelete != null) {
            System.out.print("Are you sure you want to delete this student? (y/n): ");
            String confirmation = scanner.nextLine();

            // If the user confirms, delete the student from the list
            if (confirmation.equalsIgnoreCase("y")) {
                students.remove(studentToDelete);
                System.out.println("Student with ID " + id + " has been successfully deleted.");
            } else {
                System.out.println("Student deletion canceled.");
            }
        } else {
            System.out.println("Error: Student with ID " + id + " cannot be located.");
        }

        // Option to return to the main menu or exit the application
        System.out.print("Press (1) to launch menu or any other key to exit: ");
        String choice = scanner.nextLine();
        if (!"1".equals(choice)) {
            exitStudentApplication();  // Exit if the user doesn't choose to return to the menu
        }
    }

    /**
     * Method to print a report of all students.
     * Each student's details are displayed in a formatted manner.
     * Referenced in: Main.launchManager() -> case "4"
     * Resource: "Java: The Complete Reference" by Herbert Schildt - Chapter 11 (Collections Framework)
     */
    public static void studentReport() {
        // Check if there are any students in the list
        if (students.isEmpty()) {
            System.out.println("No students found in the system.");
        } else {
            int studentNumber = 1;
            // Iterate through the list and print each student's details
            for (Student student : students) {
                System.out.println("Student " + studentNumber);
                System.out.println("------------------------------------------");
                System.out.println("Student ID: " + student.getId());
                System.out.println("Student Name: " + student.getName());
                System.out.println("Student Age: " + student.getAge());
                System.out.println("Student Email: " + student.getEmail());
                System.out.println("Student Course: " + student.getCourse());
                System.out.println("------------------------------------------");
                studentNumber++;
            }
        }

        // Option to return to the main menu or exit the application
        System.out.print("Press (1) to launch menu or any other key to exit: ");
        String choice = scanner.nextLine();
        if (!"1".equals(choice)) {
            exitStudentApplication();  // Exit if the user doesn't choose to return to the menu
        }
    }

    /**
     * Method to exit the student management application.
     * Prints a goodbye message and terminates the program.
     * Referenced in: Main.launchManager() -> case "5", Various "exit" options
     * Resource: "Java: The Complete Reference" by Herbert Schildt - Chapter 4 (Control Statements)
     */
    public static void exitStudentApplication() {
        System.out.println("Exiting the application. Goodbye!");
        System.exit(0);  // Exit the program
    }
    
     // Method to return the list of students (for testing)
    public static List<Student> getStudents() {
        return students;
    }

    // Method to clear the student list (for testing)
    public static void clearStudentList() {
        students.clear();
    }

    // Overloaded saveStudent method for testing purposes
    public static void saveStudent(String id, String name, int age, String email, String course) {
        Student student = new Student(id, name, age, email, course);
        students.add(student);
    }
   // Updated searchStudent method to return a Student object for testing purposes
    public static Student searchStudent(String id) {
        for (Student student : students) {
            if (student.getId().equals(id)) {
                return student; // Return the found student
            }
        }
        return null; // Return null if no student is found
    }
  
}





