package poesemester2;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import java.util.Scanner;

public class POEsemester2 {
    public static void main(String[] args) {
        // Main loop to keep the application running
        while (true) {
            // Display the main menu
            // Resource: "Java: The Complete Reference" by Herbert Schildt - Chapter 11 (User Interaction)
            System.out.println("Student management application:");
            System.out.println("************************************");
            System.out.println("Press (1) to launch manager or any key to exit");

            // Scanner to capture user input
            Scanner scanner = new Scanner(System.in);
            String choice = scanner.nextLine();

            if (!"1".equals(choice)) {
                // If the user chooses to exit, terminate the application
                Student.exitStudentApplication();
            } else {
                // If the user chooses to launch the manager, display the secondary menu
                System.out.println("Select from the following menu items:");
                System.out.println("(1) Capture a new student");
                System.out.println("(2) Search for a student");
                System.out.println("(3) Delete a student");
                System.out.println("(4) Print student report");
                System.out.println("(5) Exit application");

                choice = scanner.nextLine();  // Capture user's menu selection

                // Handle user's menu selection
                switch (choice) {
                    case "1":
                        // Reference to Student.saveStudent() method
                        Student.saveStudent(scanner );  // Save a new student
                        break;
                    case "2":
                        // Reference to Student.searchStudent() method
                        Student.searchStudent();  // Search for a student
                        break;
                    case "3":
                        // Reference to Student.deleteStudent() method
                        Student.deleteStudent();  // Delete a student
                        break;
                    case "4":
                        // Reference to Student.studentReport() method
                        Student.studentReport();  // Print the student report
                        break;
                    case "5":
                        // Reference to Student.exitStudentApplication() method
                        Student.exitStudentApplication();  // Exit the application
                        break;
                    default:
                        // Handle invalid menu selections
                        System.out.println("Invalid choice, please try again.");
                }
            }
        }
    }
}



    




